<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class HouseFloor extends Model
{
    protected $table = 'house_floors';

    protected $fillable = [
        'house_id',
        // pertahankan field lain yang sudah ada
    ];

    public function house(): BelongsTo
    {
        return $this->belongsTo(House::class);
    }
}