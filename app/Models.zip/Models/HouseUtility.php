<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class HouseUtility extends Model { protected $fillable=['house_id','light_opening','ventilation','lighting_source_id']; public function house(){return $this->belongsTo(House::class);} }
