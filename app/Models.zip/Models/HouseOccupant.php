<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class HouseOccupant extends Model { protected $fillable=['house_id','relationship','gender','birth_year','occupation','education','is_primary_contact']; protected function casts():array{return ['is_primary_contact'=>'boolean'];} public function house(){return $this->belongsTo(House::class);} }
