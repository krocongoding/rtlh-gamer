<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class HouseWall extends Model { protected $fillable=['house_id','material_id','condition_id']; public function house(){return $this->belongsTo(House::class);} }
