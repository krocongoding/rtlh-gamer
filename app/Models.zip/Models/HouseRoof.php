<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class HouseRoof extends Model { protected $fillable=['house_id','frame_condition_id','material_id','condition_id']; public function house(){return $this->belongsTo(House::class);} }
