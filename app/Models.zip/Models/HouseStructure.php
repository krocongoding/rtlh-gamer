<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class HouseStructure extends Model { protected $fillable=['house_id','foundation','sloof_condition_id','column_condition_id','beam_condition_id']; public function house(){return $this->belongsTo(House::class);} }
